import java.util.Scanner;

public class PronicNumber {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = sc.nextInt();

        boolean flag = false;

        for (int i = 1; i <= num; i++) {
            if (i * (i + 1) == num) {
                flag = true;
                break;
            }
        }

        if (flag) {
            System.out.println(num + " is a Pronic Number");
        } else {
            System.out.println(num + " is not a Pronic Number");
        }
    }
}