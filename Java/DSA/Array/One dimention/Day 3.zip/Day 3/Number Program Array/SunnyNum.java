class SunnyNum {
    static int count = 0;

    public static void main(String[] args) {
        int[] arr = {12, 34, 55, 33, 31, 59, 39, 8, 18};

        index(arr);
        System.out.println("Count: " + count);
    }

    public static void index(int[] num) {
        for (int i = 0; i < num.length; i++) {
            if (sunnyNum(num[i])) {
                count++;
                System.out.println(num[i]);
            }
        }
    }

    public static boolean sunnyNum(int num) {
        int n = num+1;
        int sum = 0;

     for (int i = 0;i<= n; i++)
     {
		 if (i*i == n)
		 {
			 return true;
		 }
     }
        return false;
    }
}