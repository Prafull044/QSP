// Segregate Multiples of 3 and Others
import java.util.Arrays;
class  Multiple
{
	public static void main(String[] args) 
	{
		int [] arr = {12,545,322,45,15,323,6,7,8,243,53,345435,43,453,4,435,435,35,345,45,34534525,5,24,52};
		multi(arr);
		System.out.println(Arrays.toString(arr));
	}
	
	public static void multi(int [] num)
	{
		int i = 0;
		int j = num.length - 1;
		while(i< j)
		{
			if(num[i] % 3 == 0)
			{
				i++;
			}else if(num[j] % 3 != 0)
			{
				j--;
			}else
			{
				int temp = num[i];
				num[i] = num[j];
				num[j] = temp;
			}
		}
	}
}
