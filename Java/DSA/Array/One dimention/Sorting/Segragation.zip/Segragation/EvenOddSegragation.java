//1] Segregate Even and Odd Numbers
import java.util.Arrays;
class EvenOddSegragation 
{
	public static void main(String[] args) 
	{
		int [] arr = {12,34,55,33,22,4532,433,3242};
		evenOddSeg(arr);
		System.out.println(Arrays.toString(arr));
	}
	
	public static void evenOddSeg(int [] num)
	{
	   int i = 0;
	   int j = num.length - 1;
	   while(i < j)
		{
			if(num[i] % 2 == 0)
			{
				i++;
			}else if(num[j] % 2 != 0){
				j--;
			}else{
				int temp = num[i];
				num[i] = num[j];
				num[j] = temp;
			}
		}
	}
}
